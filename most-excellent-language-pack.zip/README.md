# Description

It makes the game more fun, trust me

Replaces various text with bad jokes and references.

# Contributing

- I'm open to PRs and issues on github if you really want to, but they are entirely subject to my personal sense of humor as the only criteria for inclusion.
- Instructions for finding token names are [here](https://github.com/risk-of-thunder/R2Wiki/wiki/Mod-Creation_Assets_Localization)
